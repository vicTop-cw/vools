---
name: python-refactor-test-debug
agent_created: true
description: Use when refactoring a Python module, fixing test failures after reorganization, or debugging discrepancies between direct execution and pytest. Covers import migration, closure-capture bugs, cached expression evaluation, and test normalization.
---

# Python 模块重构与测试调试

## 概述

本技能用于指导 Python 模块重构、包结构调整后的导入修复，以及测试在 pytest 与直接执行时出现不一致的排查。

## 何时使用

- 拆分/合并 Python 包（如将 `__init__.py` 中的多个装饰器拆分为独立模块）。
- 将绝对导入改为相对导入，或重命名子包后修复残留导入。
- 优化复杂装饰器/元类代码并补充单元测试。
- 测试在 `pytest` 中失败，但直接运行 `python test_file.py` 或通过交互式导入成功。

## 标准工作流程

### 1. 读取原始代码与测试

- 读取要重构的源文件、原始测试文件或 `if __name__ == '__main__':` 示例块。
- 明确原始意图：哪些行为是 bug、哪些行为是特性，避免误改。
- 如果文件很长，分段读取关键函数（使用 `Read` 的 `offset`/`limit`）。

### 2. 规划重构步骤

按以下优先级拆分任务：

1. 修复 P0 级语法/运行时错误（如 `x.match(...)` 应为 `re.match(...)`）。
2. 修复明显拼写错误（如 `reuslt`）。
3. 提取公共逻辑到独立辅助函数，减少重复。
4. 用更安全/标准的方式替换脆弱实现（如 `ast.literal_eval` 替换手动字符串解析）。
5. 缓存重复编译/求值（如 `compile` 和 `eval` 结果）。
6. 修复循环闭包变量捕获（使用工厂函数绑定每次迭代的值）。

### 3. 处理导入与包结构

- 将内部绝对导入改为相对导入：
  - `from vools.xxx import ...` → `from ..xxx import ...` 或 `from .xxx import ...`。
- 子包拆分后，在新包 `__init__.py` 中重新导出公共接口，保持向后兼容：
  - 旧入口点保留为薄重新导出模块（如 `vools/decorators/cache.py` 只 `from ..cache import ...`）。
- 使用 `Grep` 全面搜索残留旧导入：
  - `vools\.old_name` 在 `vools/` 源码中必须清零。
  - 测试文件、调试脚本、文档中的示例也需同步更新。

### 4. 修复测试不一致

当 pytest 失败但直接执行成功时，按顺序检查：

1. **导入路径**：测试文件是否通过 `sys.path.insert(0, ...)` 引用了项目根目录；pytest 的 `rootdir` 是否一致。
2. **模块初始化顺序**：`vools/__init__.py` 的 `__getattr__` 或延迟加载是否在不同导入方式下产生不同状态。
3. **全局/模块级缓存**：
   - 缓存字典（如 `{expr: compiled_code}`）是否被污染。
   - 在测试间使用 `setup_method`/`teardown_method` 清理缓存。
4. **闭包捕获**：循环中定义函数时，确保使用工厂函数或默认参数绑定变量。
5. **表达式求值作用域**：
   - `exec(code, globals, locals)` 对增强赋值（`result *= 2`）修改的是 `locals`。
   - 后续 `eval` 要从 `locals` 读取更新后的值，因此 `globals` 和 `locals` 必须配对传递。
6. **测试配置格式**：对照文档字符串/源码元组解包，确认 `return_result`、`deco` 等字段位置正确，避免多余的 `None` 占位符导致字段错位。

### 5. 测试策略

- 先运行目标测试文件：`python -m pytest tests/test_xxx.py -v`。
- 目标通过后再运行相关模块回归测试：
  - 排除会访问系统剪贴板、键盘、文件系统监控的集成测试（沙箱容易拒绝）。
- 对于 pre-existing 失败，明确记录其与本次修改无关，不扩大范围。

## 常见陷阱

- **字符串返回值 vs 变量**：`return: 'self'` 在字典配置中应优先解析为环境变量 `self`，否则返回字符串字面量。实现时检查 `value.isidentifier() and value in env`。
- **@clone 省略 None**：`@clone('attr:value')` 与 `@clone(None, 'attr:value')` 都应支持。在 `clone` 函数开头判断第一个参数是否为类，不是则并入 `args`。
- **元组字段错位**：`copy_list_from` 的格式为 `(source, methods_or_filter, init_args, init_kwargs, return_result, deco)`，写测试时避免插入多余 `None` 导致 `return_result` 落在错误位置。
- **分号表达式**：`=> result * 2; result + 10` 不会修改 `result`；若需链式更新，应使用 `result *= 2; result + 10` 或显式赋值。

## 资源

本技能不包含额外脚本或模板文件。核心流程依赖通用工具（`Read`、`Edit`、`Write`、`Grep`、`Bash`）和项目自身的测试套件。
